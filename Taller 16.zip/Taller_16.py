

x=[0,1,2,3,4,5,6,7]
y=[3.5,2.5,3,1.5,2,1.3,1,0.3]

n=(len(x))
sumaX=0
sumaY=0 
sumaXelevado=0
sumaXY=0

for elem in y: 
  sumaY+=elem

promedioY=sumaY/n 

for elem in x: 
  sumaX+=elem

  elevado=elem**2
  sumaXelevado+=elevado
promedioX=sumaX/n

for i in range(len(x)):
  sumaXY+=x[i]*y[i]

a1=(n*sumaXY-sumaX*sumaY)/(n*sumaXelevado-(sumaX)**2)

a0=promedioY-a1*promedioX 

print("la formula es: ",a0,"+",a1,"X")



  




